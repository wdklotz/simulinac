;mw.loader.state({"site":"ready"});

/* cache key: wikidb:resourceloader:filter:minify-js:7:8dfa90551a65a23504298dbdfe1aa1cd */